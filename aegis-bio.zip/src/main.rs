use eframe::egui;
use egui_plot::{Line, Plot, PlotPoints};
use std::collections::VecDeque;

fn main() -> Result<(), eframe::Error> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1200.0, 800.0])
            .with_title("A.S.T.R.O. - Terminal OS"),
        ..Default::default()
    };

    eframe::run_native(
        "AstroOS CRT Monitor",
        options,
        Box::new(|_cc| Box::new(AstroOsApp::default())),
    )
}

// Arayüzün durumunu takip eden Enum
#[derive(PartialEq)]
enum ViewState {
    Dashboard,
    HealthDetailFullScreen,
}

struct AstroOsApp {
    state: ViewState,
    
    // Tema ve Ayarlar
    theme_color: egui::Color32,
    brightness: f32,
    show_settings: bool,

    // Sağlık Monitörü Verileri
    radiation: f32,
    oxygen: f32,
    isolation_pivot: f32,
    blood_pressure: f32,
    nitrogen_ratio: f32,
    hemoglobin: f32,
    heart_rate_base: f32,

    // Grafik ve Animasyon
    time: f64,
    hr_history: VecDeque<[f64; 2]>,
    
    // Terminal
    terminal_logs: Vec<String>,
    terminal_input: String,
}

impl Default for AstroOsApp {
    fn default() -> Self {
        Self {
            state: ViewState::Dashboard,
            
            theme_color: egui::Color32::from_rgb(0, 255, 60),
            brightness: 1.0,
            show_settings: false,
            
            radiation: 12.5,
            oxygen: 98.0,
            isolation_pivot: 50.0,
            blood_pressure: 120.0,
            nitrogen_ratio: 78.0,
            hemoglobin: 14.5,
            heart_rate_base: 75.0,
            
            time: 0.0,
            hr_history: VecDeque::new(),
            terminal_logs: vec![
                "[SİSTEM] AstroOS v1.0.5 Yüklendi...".to_string(), 
                "[SİSTEM] 'settings' yazarak tema ayarlarını açabilirsiniz.".to_string(),
            ],
            terminal_input: String::new(),
        }
    }
}

impl AstroOsApp {
    // ---------------------------------------------------------
    // ÇİZİM VE TEMA FONKSİYONLARI (İLK DOSYADAN)
    // ---------------------------------------------------------
    fn crt_color(&self) -> egui::Color32 {
        let r = (self.theme_color.r() as f32 * self.brightness).clamp(0.0, 255.0) as u8;
        let g = (self.theme_color.g() as f32 * self.brightness).clamp(0.0, 255.0) as u8;
        let b = (self.theme_color.b() as f32 * self.brightness).clamp(0.0, 255.0) as u8;
        egui::Color32::from_rgba_premultiplied(r, g, b, 255)
    }

    fn apply_crt_theme(&self, ctx: &egui::Context) {
        let mut visuals = egui::Visuals::dark();
        let crt_c = self.crt_color();
        
        visuals.window_rounding = egui::Rounding::ZERO;
        visuals.widgets.noninteractive.rounding = egui::Rounding::ZERO;
        visuals.widgets.inactive.rounding = egui::Rounding::ZERO;
        visuals.widgets.hovered.rounding = egui::Rounding::ZERO;
        visuals.widgets.active.rounding = egui::Rounding::ZERO;
        
        visuals.window_fill = egui::Color32::BLACK;
        visuals.panel_fill = egui::Color32::BLACK;
        visuals.override_text_color = Some(crt_c);
        
        ctx.set_visuals(visuals);

        let mut style = (*ctx.style()).clone();
        style.text_styles.iter_mut().for_each(|(_, font_id)| {
            font_id.family = egui::FontFamily::Monospace;
        });
        ctx.set_style(style);
    }

    // İlk tasarımdaki dikey, büyük yüzdeli dikdörtgen çubuklar (Detay ekranı için)
    fn custom_vertical_bar(&self, ui: &mut egui::Ui, value: f32, max: f32, label: &str) {
        let fraction = (value / max).clamp(0.0, 1.0);
        let current_color = self.crt_color();
        
        ui.horizontal(|ui| {
            let size = egui::vec2(60.0, 200.0);
            let (rect, _response) = ui.allocate_exact_size(size, egui::Sense::hover());

            ui.painter().rect_stroke(rect, 0.0, egui::Stroke::new(2.0, current_color));

            let fill_height = fraction * rect.height();
            let fill_rect = egui::Rect::from_min_max(
                egui::pos2(rect.min.x, rect.max.y - fill_height),
                rect.max
            );
            ui.painter().rect_filled(fill_rect, 0.0, current_color);

            ui.vertical(|ui| {
                ui.add_space(size.y / 2.0 - 20.0);
                ui.label(egui::RichText::new(format!("%{:.1}", fraction * 100.0)).size(36.0).color(current_color));
                ui.label(egui::RichText::new(label).size(18.0).color(current_color));
            });
        });
    }

    // ---------------------------------------------------------
    // İKİNCİ TASARIMDAN: DEV TIKLANABİLİR SAĞLIK BUTONU
    // ---------------------------------------------------------
    fn draw_complex_health_button(&mut self, ui: &mut egui::Ui) -> egui::Response {
        let frame = egui::Frame::none()
            .fill(egui::Color32::from_black_alpha(0))
            .stroke(egui::Stroke::new(2.0, self.crt_color()))
            .inner_margin(20.0);

        let response = frame.show(ui, |ui| {
            ui.set_width(450.0); 
            
            // 1. Animasyonlu Kalp ve BPM
            ui.horizontal(|ui| {
                let hz = self.heart_rate_base as f64 / 60.0;
                let phase = self.time * std::f64::consts::PI * 2.0 * hz;
                let pulse = phase.sin().max(0.0).powf(4.0); 
                let scale = 1.0 + 0.4 * pulse as f32;
                
                let heart_color = egui::Color32::from_rgb(
                    (255.0 * pulse as f32).clamp(100.0, 255.0) as u8, 0, 0
                );
                
                ui.label(egui::RichText::new("❤").size(50.0 * scale).color(heart_color));
                ui.add_space(30.0);
                ui.label(egui::RichText::new(format!("{:.0} BPM", self.heart_rate_base)).size(40.0).color(self.crt_color()));
            });
            
            ui.add_space(20.0);
            
            // 2. Yatay Barlar (Butonun içi için)
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("O2 SEVİYESİ: ").size(18.0).color(self.crt_color()));
                let p = egui::ProgressBar::new(self.oxygen / 100.0).fill(self.crt_color());
                ui.add_sized([180.0, 20.0], p);
                ui.label(egui::RichText::new(format!("%{:.1}", self.oxygen)).size(18.0).color(self.crt_color()));
            });
            
            ui.add_space(10.0);
            
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("RADYASYON  : ").size(18.0).color(self.crt_color()));
                let p = egui::ProgressBar::new(self.radiation / 100.0).fill(self.crt_color());
                ui.add_sized([180.0, 20.0], p);
                ui.label(egui::RichText::new(format!("%{:.1}", self.radiation)).size(18.0).color(self.crt_color()));
            });
            
            ui.add_space(20.0);
            ui.label(egui::RichText::new("Durum Raporu: AKTİF. Detaylar için TIKLAYIN.").color(self.crt_color()));
        }).response;

        let interact_response = ui.interact(response.rect, ui.id().with("health_btn"), egui::Sense::click())
            .on_hover_cursor(egui::CursorIcon::PointingHand);
        
        if interact_response.hovered() {
            ui.painter().rect_stroke(response.rect, 0.0, egui::Stroke::new(3.0, egui::Color32::WHITE));
        }

        interact_response
    }
}

impl eframe::App for AstroOsApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_crt_theme(ctx);

        // Canlı veri simülasyonu (Animasyonlar için)
        self.time += ctx.input(|i| i.stable_dt) as f64;
        let current_hr = self.heart_rate_base as f64 + (self.time * 5.0).sin() * 10.0;
        self.hr_history.push_back([self.time, current_hr]);
        if self.hr_history.len() > 300 { self.hr_history.pop_front(); }
        ctx.request_repaint(); 

        // ---------------------------------------------------------
        // AYARLAR PENCERESİ (Bağımsız - Her Ekrandan Erişilebilir)
        // ---------------------------------------------------------
        if self.show_settings {
            egui::Window::new("Ayar Konsolu").open(&mut self.show_settings).show(ctx, |ui| {
                ui.label("Sistem Tema Rengi (RGBA):");
                ui.color_edit_button_srgba(&mut self.theme_color);
                ui.add_space(10.0);
                ui.label("CRT Parlaklığı:");
                ui.add(egui::Slider::new(&mut self.brightness, 0.1..=3.0));
            });
        }

        // ---------------------------------------------------------
        // EKRAN DURUMLARINA GÖRE ARAYÜZ
        // ---------------------------------------------------------
        match self.state {
            ViewState::Dashboard => {
                // ALT PANEL: CMD Terminal / Input-Output
                egui::TopBottomPanel::bottom("cmd_panel").exact_height(150.0).show(ctx, |ui| {
                    ui.heading(">_ ASTRO TERMINAL (I/O)");
                    ui.separator();
                    egui::ScrollArea::vertical().max_height(80.0).stick_to_bottom(true).show(ui, |ui| {
                        for log in &self.terminal_logs { ui.label(log); }
                    });
                    
                    ui.horizontal(|ui| {
                        ui.label("root@astro:~# ");
                        let response = ui.add(egui::TextEdit::singleline(&mut self.terminal_input).desired_width(f32::INFINITY).frame(false));
                        if response.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                            if self.terminal_input == "settings" {
                                self.show_settings = true;
                            } else if !self.terminal_input.is_empty() {
                                let log = format!("> {}", self.terminal_input);
                                self.terminal_logs.push(log);
                                self.terminal_logs.push("[SİSTEM] Bilinmeyen Komut".to_string());
                            }
                            self.terminal_input.clear();
                            response.request_focus();
                        }
                    });